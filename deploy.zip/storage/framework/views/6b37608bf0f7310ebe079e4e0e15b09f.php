<div
    x-data
    x-on:advanced-table-export-copy-to-clipboard.window="window.navigator.clipboard.writeText($event.detail.content)"
></div>
<?php /**PATH /Users/macbook/Kasira-Laravel/vendor/occtherapist/advanced-table-export-for-filament/src/../resources/views/clipboard-listener.blade.php ENDPATH**/ ?>