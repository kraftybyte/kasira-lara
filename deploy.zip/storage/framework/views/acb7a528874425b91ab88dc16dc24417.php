<svg class="h-3.5 w-3.5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true" data-slot="icon">
  <path stroke-linecap="round" stroke-linejoin="round" d="M12 4.5v15m7.5-7.5h-15"/>
</svg><?php /**PATH /Users/macbook/Kasira-Laravel/storage/framework/views/2757f7d08eed7fa5e0ffeb9d003d1466.blade.php ENDPATH**/ ?>