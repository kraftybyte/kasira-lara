<svg class="h-8 w-8" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true" data-slot="icon">
  <path stroke-linecap="round" stroke-linejoin="round" d="m4.5 12.75 6 6 9-13.5"/>
</svg><?php /**PATH /Users/macbook/Kasira-Laravel/storage/framework/views/b7ef207702ad4ca7ec04a0426dadf514.blade.php ENDPATH**/ ?>