<div <?php echo e($attributes->class(['fi-dropdown-list'])); ?>>
    <?php echo e($slot); ?>

</div>
<?php /**PATH /Users/macbook/Kasira-Laravel/resources/views/vendor/filament/components/dropdown/list/index.blade.php ENDPATH**/ ?>